import { Routes, Route, Navigate } from 'react-router-dom';
import { PrivateRoute } from './PrivateRoute';
import Login from '@/pages/login';
import Layout from '@/layouts';
import Home from '@/pages/home';
import DingtalkFormConfig from '@/pages/dingtalk/form-config';
import DingtalkOaFormData from '@/pages/dingtalk/oa-form-data';
import KingdeeVoucher from '@/pages/kingdee/voucher';
import KingdeeSupplier from '@/pages/kingdee/supplier';
import KingdeeAccount from '@/pages/kingdee/account';
import ExpenseReimbursement from '@/pages/business/expense-reimbursement';
import FundUsageApplication from '@/pages/business/fund-usage-application';
import VehicleReceiptStatistics from '@/pages/business/vehicle-receipt-statistics';
import PaymentApplication from '@/pages/business/payment-application';
import RepairWorkOrder from '@/pages/business/repair-work-order';
import InspectionLocation from '@/pages/inspection-location';
import MobileForm from '@/pages/mobile/form';
import InspectionForm from '@/pages/mobile/inspection-form';

export default function Router() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      {/* 独立路由 - 无需登录即可访问 */}
      <Route path="/mobile/form" element={<MobileForm />} />
      <Route path="/mobile/inspection-form" element={<InspectionForm />} />
      <Route
        path="/"
        element={
          <PrivateRoute>
            <Layout />
          </PrivateRoute>
        }
      >
        <Route index element={<Navigate to="/home" replace />} />
        <Route path="home" element={<Home />} />
        <Route path="dingtalk/form-config" element={<DingtalkFormConfig />} />
        <Route path="dingtalk/oa-form-data" element={<DingtalkOaFormData />} />
        <Route path="business/expense-reimbursement" element={<ExpenseReimbursement />} />
        <Route path="business/fund-usage-application" element={<FundUsageApplication />} />
        <Route path="business/vehicle-receipt-statistics" element={<VehicleReceiptStatistics />} />
        <Route path="business/payment-application" element={<PaymentApplication />} />
        <Route path="business/repair-work-order" element={<RepairWorkOrder />} />
        <Route path="inspection-location" element={<InspectionLocation />} />
        <Route path="kingdee/voucher" element={<KingdeeVoucher />} />
        <Route path="kingdee/supplier" element={<KingdeeSupplier />} />
        <Route path="kingdee/account" element={<KingdeeAccount />} />
      </Route>
      <Route path="*" element={<Navigate to="/home" replace />} />
    </Routes>
  );
}
