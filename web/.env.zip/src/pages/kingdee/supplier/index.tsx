import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Card,
  Table,
  Form,
  Input,
  Button,
  Row,
  Col,
  message,
  Tag,
} from 'antd';
import { DatabaseOutlined, SearchOutlined } from '@ant-design/icons';
import type { ColumnsType } from 'antd/es/table';
import {
  getKingdeeSupplierPage,
  type SupplierDetailVO,
  type KingdeeSupplierQueryParams,
} from '@/api/kingdee';
import KingdeeAccountSelect from '@/components/kingdee/KingdeeAccountSelect';
import {
  applyKingdeeAccountToSupplierForm,
  useKingdeeAccountSelect,
} from '@/hooks/useKingdeeAccountSelect';

interface SupplierQueryForm {
  accountId: number;
  supplierNumber: string;
  supplierName: string;
  useOrgCode: string;
}

const DOCUMENT_STATUS_MAP: Record<string, { label: string; color: string }> = {
  Z: { label: '暂存', color: 'default' },
  A: { label: '创建', color: 'processing' },
  B: { label: '审核中', color: 'warning' },
  C: { label: '已审核', color: 'success' },
  D: { label: '重新审核', color: 'error' },
};

const FORBID_STATUS_MAP: Record<string, { label: string; color: string }> = {
  A: { label: '否', color: 'success' },
  B: { label: '是', color: 'error' },
};

export default function KingdeeSupplierPage() {
  const [loading, setLoading] = useState(false);
  const [tableData, setTableData] = useState<SupplierDetailVO[]>([]);
  const [total, setTotal] = useState(0);
  const [pageNo, setPageNo] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [queryConfig, setQueryConfig] = useState<KingdeeSupplierQueryParams | null>(null);
  const [form] = Form.useForm<SupplierQueryForm>();
  const initialQueryDone = useRef(false);
  const {
    accounts,
    loading: accountsLoading,
    setSelectedAccountId,
    selectedAccount,
  } = useKingdeeAccountSelect();

  const fetchData = useCallback(async (config: KingdeeSupplierQueryParams) => {
    setLoading(true);
    try {
      const res = await getKingdeeSupplierPage({
        ...config,
        pageNo: config.pageNo ?? pageNo,
        pageSize: config.pageSize ?? pageSize,
      });
      setTableData(res.data.records);
      setTotal(res.data.total);
    } catch {
      message.error('查询金蝶供应商失败');
    } finally {
      setLoading(false);
    }
  }, [pageNo, pageSize]);

  useEffect(() => {
    if (accountsLoading || initialQueryDone.current) {
      return;
    }
    if (!selectedAccount) {
      initialQueryDone.current = true;
      return;
    }

    applyKingdeeAccountToSupplierForm(selectedAccount, form);

    (async () => {
      try {
        const values = await form.validateFields();
        const config: KingdeeSupplierQueryParams = {
          accountId: values.accountId,
          supplierNumber: values.supplierNumber,
          supplierName: values.supplierName,
          useOrgCode: values.useOrgCode,
          pageNo: 1,
          pageSize,
        };
        setPageNo(1);
        setQueryConfig(config);
        await fetchData(config);
      } catch {
        // validation failed or query failed
      } finally {
        initialQueryDone.current = true;
      }
    })();
  }, [accountsLoading, selectedAccount, form, fetchData, pageSize]);

  const handleQuery = async () => {
    try {
      const values = await form.validateFields();
      setPageNo(1);
      const config: KingdeeSupplierQueryParams = {
        accountId: values.accountId,
        supplierNumber: values.supplierNumber,
        supplierName: values.supplierName,
        useOrgCode: values.useOrgCode,
        pageNo: 1,
        pageSize,
      };
      setQueryConfig(config);
      await fetchData(config);
    } catch {
      // validation failed
    }
  };

  const handlePageChange = async (page: number, size: number) => {
    setPageNo(page);
    setPageSize(size);
    if (queryConfig) {
      await fetchData({ ...queryConfig, pageNo: page, pageSize: size });
    }
  };

  const handleAccountChange = (accountId: number) => {
    setSelectedAccountId(accountId);
    const account = accounts.find((item) => item.id === accountId);
    applyKingdeeAccountToSupplierForm(account, form);
  };

  const renderStatusTag = (value: string | undefined, map: Record<string, { label: string; color: string }>) => {
    if (!value) return '-';
    const item = map[value];
    return item ? <Tag color={item.color}>{item.label}</Tag> : value;
  };

  const columns: ColumnsType<SupplierDetailVO> = [
    { title: '供应商编码', dataIndex: 'fnumber', width: 140, fixed: 'left' },
    { title: '供应商名称', dataIndex: 'fname', width: 200, ellipsis: true },
    { title: '简称', dataIndex: 'fshortName', width: 120, ellipsis: true },
    { title: '供应商分组', dataIndex: 'fgroupName', width: 140, ellipsis: true },
    {
      title: '数据状态',
      dataIndex: 'fdocumentStatus',
      width: 100,
      render: (value: string) => renderStatusTag(value, DOCUMENT_STATUS_MAP),
    },
    {
      title: '禁用状态',
      dataIndex: 'fforbidStatus',
      width: 100,
      render: (value: string) => renderStatusTag(value, FORBID_STATUS_MAP),
    },
    { title: '创建日期', dataIndex: 'fcreateDate', width: 120 },
    { title: '使用组织', dataIndex: 'fuseOrgName', width: 160, ellipsis: true },
    { title: '税号', dataIndex: 'ftaxRegisterCode', width: 180, ellipsis: true },
    { title: '联系人', dataIndex: 'fcontact', width: 100 },
    { title: '联系电话', dataIndex: 'ftel', width: 130 },
    { title: '地址', dataIndex: 'faddress', width: 220, ellipsis: true },
    { title: '描述', dataIndex: 'fdescription', width: 200, ellipsis: true },
  ];

  return (
    <div style={{ padding: 24 }}>
      <Card title="查询条件" style={{ marginBottom: 16 }}>
        <Form form={form} layout="vertical">
          <KingdeeAccountSelect
            accounts={accounts}
            loading={accountsLoading}
            onChange={handleAccountChange}
          />
          <Row gutter={16}>
            <Col span={8}>
              <Form.Item label="供应商编码" name="supplierNumber">
                <Input placeholder="模糊匹配，可选" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="供应商名称" name="supplierName">
                <Input placeholder="模糊匹配，可选" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="使用组织编码" name="useOrgCode">
                <Input placeholder="精确匹配，可选" />
              </Form.Item>
            </Col>
          </Row>
          <Button
            type="primary"
            icon={<DatabaseOutlined />}
            onClick={handleQuery}
            loading={loading}
            disabled={accounts.length === 0}
          >
            查询供应商
          </Button>
        </Form>
      </Card>

      <Card
        title="金蝶供应商列表"
        extra={
          queryConfig && (
            <Button
              icon={<SearchOutlined />}
              onClick={() => fetchData({ ...queryConfig, pageNo, pageSize })}
              loading={loading}
            >
              刷新
            </Button>
          )
        }
      >
        <Table
          rowKey={(record, index) => `${record.fnumber}-${index}`}
          columns={columns}
          dataSource={tableData}
          loading={loading}
          scroll={{ x: 1800 }}
          pagination={{
            current: pageNo,
            pageSize,
            total,
            showSizeChanger: true,
            showTotal: (t) => `共 ${t} 条`,
            onChange: handlePageChange,
          }}
        />
      </Card>
    </div>
  );
}
