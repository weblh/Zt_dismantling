import { useState, useEffect, useCallback } from 'react';
import { Card, Table, Input, Button } from 'antd';
import { FilterOutlined, ColumnWidthOutlined, FullscreenOutlined, MoreOutlined, CheckCircleOutlined } from '@ant-design/icons';
import type { ColumnsType } from 'antd/es/table';

interface SyncDataItem {
  id: number;
  code: string;
  isNegotiated: boolean;
  tonnage: string;
  status: string;
  submitter: string;
  submitTime: string;
  updateTime: string;
}

const mockData: SyncDataItem[] = [
  { id: 1, code: '695431', isNegotiated: true, tonnage: '1.05', status: '0', submitter: '', submitTime: '2026-07-22 14:06:00', updateTime: '2026-07-22 14:09:47' },
  { id: 2, code: '695430', isNegotiated: true, tonnage: '1.31', status: '0', submitter: '', submitTime: '2026-07-22 14:05:15', updateTime: '2026-07-22 14:09:15' },
  { id: 3, code: '695429', isNegotiated: true, tonnage: '1.1', status: '0', submitter: '', submitTime: '2026-07-22 14:04:35', updateTime: '2026-07-22 14:08:28' },
  { id: 4, code: '695428', isNegotiated: true, tonnage: '1.13', status: '0', submitter: '', submitTime: '2026-07-22 09:31:05', updateTime: '2026-07-22 09:31:35' },
  { id: 5, code: '695427', isNegotiated: true, tonnage: '1.12', status: '0', submitter: '', submitTime: '2026-07-21 10:09:07', updateTime: '2026-07-21 10:14:19' },
  { id: 6, code: '695426', isNegotiated: true, tonnage: '0.89', status: '0', submitter: '', submitTime: '2026-07-20 14:22:15', updateTime: '2026-07-20 14:24:26' },
  { id: 7, code: '695425', isNegotiated: true, tonnage: '1.13', status: '0', submitter: '', submitTime: '2026-07-16 09:26:36', updateTime: '2026-07-16 09:33:06' },
  { id: 8, code: '695424', isNegotiated: true, tonnage: '1.16', status: '0', submitter: '', submitTime: '2026-07-16 09:26:36', updateTime: '2026-07-16 09:32:37' },
  { id: 9, code: '695423', isNegotiated: true, tonnage: '1.16', status: '0', submitter: '', submitTime: '2026-07-16 09:26:36', updateTime: '2026-07-16 09:22:12' },
  { id: 10, code: '695422', isNegotiated: true, tonnage: '0.86', status: '0', submitter: '', submitTime: '2026-07-16 09:18:33', updateTime: '2026-07-16 09:21:26' },
  { id: 11, code: '695421', isNegotiated: true, tonnage: '1.45', status: '0', submitter: '', submitTime: '2026-07-15 17:59:18', updateTime: '2026-07-15 18:00:56' },
  { id: 12, code: '695420', isNegotiated: true, tonnage: '1.11', status: '0', submitter: '', submitTime: '2026-07-15 17:53:08', updateTime: '2026-07-15 17:54:05' },
  { id: 13, code: '695419', isNegotiated: true, tonnage: '1.11', status: '0', submitter: '', submitTime: '2026-07-15 17:48:13', updateTime: '2026-07-15 17:50:08' },
  { id: 14, code: '695418', isNegotiated: true, tonnage: '1.19', status: '0', submitter: '', submitTime: '2026-07-15 17:43:23', updateTime: '2026-07-15 17:45:18' },
  { id: 15, code: '695417', isNegotiated: true, tonnage: '1.12', status: '0', submitter: '', submitTime: '2026-07-15 17:38:38', updateTime: '2026-07-15 17:44:57' },
  { id: 16, code: '695416', isNegotiated: true, tonnage: '1.86', status: '0', submitter: '', submitTime: '2026-07-15 17:35:14', updateTime: '2026-07-15 17:37:30' },
  { id: 17, code: '695415', isNegotiated: true, tonnage: '1.66', status: '0', submitter: '', submitTime: '2026-07-15 12:06:58', updateTime: '2026-07-15 12:32:44' },
  { id: 18, code: '695414', isNegotiated: true, tonnage: '1.57', status: '0', submitter: '', submitTime: '2026-07-15 11:18:16', updateTime: '2026-07-15 11:23:58' },
  { id: 19, code: '695413', isNegotiated: true, tonnage: '1.44', status: '0', submitter: '', submitTime: '2026-07-15 11:18:16', updateTime: '2026-07-15 11:22:44' },
  { id: 20, code: '695412', isNegotiated: true, tonnage: '1.28', status: '0', submitter: '', submitTime: '2026-07-15 11:02:48', updateTime: '2026-07-15 11:07:49' },
];

const columns: ColumnsType<SyncDataItem> = [
  { title: '编号', dataIndex: 'code', width: 100 },
  {
    title: '议价/销户',
    width: 100,
    render: (_value, record) => (
      record.isNegotiated ? <CheckCircleOutlined style={{ color: '#52c41a' }} /> : '-'
    ),
  },
  { title: '吨位', dataIndex: 'tonnage', width: 80 },
  { title: '状态', dataIndex: 'status', width: 60 },
  { title: '提交人', dataIndex: 'submitter', width: 100 },
  { title: '提交时间', dataIndex: 'submitTime', width: 170 },
  { title: '更新时间', dataIndex: 'updateTime', width: 170 },
];

export default function SyncDataPage() {
  const [items, setItems] = useState<SyncDataItem[]>([]);
  const [total, setTotal] = useState(0);
  const [pageNo, setPageNo] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [loading, setLoading] = useState(false);
  const [searchValue, setSearchValue] = useState('');

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 500));
      let filteredData = [...mockData];
      if (searchValue) {
        filteredData = filteredData.filter((item) =>
          item.code.includes(searchValue),
        );
      }
      setItems(filteredData);
      setTotal(filteredData.length);
    } catch {
    } finally {
      setLoading(false);
    }
  }, [searchValue]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleSearch = (value: string) => {
    setSearchValue(value);
    setPageNo(1);
  };

  return (
    <div className="page-container">
      <Card title="查看全部数据" style={{ margin: 0, borderRadius: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', marginBottom: 16, gap: 12 }}>
          <Input.Search
            placeholder="搜索数据"
            value={searchValue}
            onChange={(e) => handleSearch(e.target.value)}
            style={{ width: 200 }}
          />
          <Button icon={<FilterOutlined />}>筛选</Button>
          <ColumnWidthOutlined style={{ fontSize: 16, cursor: 'pointer', color: '#666' }} />
          <FullscreenOutlined style={{ fontSize: 16, cursor: 'pointer', color: '#666' }} />
          <MoreOutlined style={{ fontSize: 16, cursor: 'pointer', color: '#666' }} />
        </div>

        <Table
          rowKey="id"
          columns={columns}
          dataSource={items}
          loading={loading}
          pagination={{
            current: pageNo,
            pageSize,
            total,
            showSizeChanger: true,
            showTotal: (t) => `共 ${t} 条`,
            onChange: (page, size) => {
              setPageNo(page);
              setPageSize(size);
            },
          }}
        />
      </Card>
    </div>
  );
}