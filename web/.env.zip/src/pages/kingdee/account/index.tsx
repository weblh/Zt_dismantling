import { useCallback, useEffect, useState } from 'react';
import {
  Card,
  Table,
  Form,
  Input,
  Button,
  Tag,
  Space,
  Modal,
  message,
  Popconfirm,
  Select,
  Switch,
} from 'antd';
import {
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  CheckCircleOutlined,
  StopOutlined,
  StarOutlined,
  ApiOutlined,
} from '@ant-design/icons';
import type { ColumnsType } from 'antd/es/table';
import {
  getKingdeeAccounts,
  createKingdeeAccount,
  updateKingdeeAccount,
  deleteKingdeeAccount,
  toggleKingdeeAccountStatus,
  setDefaultKingdeeAccount,
  testKingdeeAccountLogin,
  type KingdeeAccountConfig,
} from '@/api/kingdee';

interface AccountFormValues {
  accountName: string;
  kingdeeUrl: string;
  dbId: string;
  username: string;
  password?: string;
  orgCompanyCode?: string;
  useOrgCode?: string;
  defaultFormId?: string;
  defaultAccountingPeriod?: string;
  isDefault?: boolean;
  status?: number;
  description?: string;
}

export default function KingdeeAccountPage() {
  const [accounts, setAccounts] = useState<KingdeeAccountConfig[]>([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [testingId, setTestingId] = useState<number | null>(null);
  const [form] = Form.useForm<AccountFormValues>();

  const fetchAccounts = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getKingdeeAccounts();
      setAccounts(res.data);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAccounts();
  }, [fetchAccounts]);

  const handleAdd = () => {
    setEditingId(null);
    form.resetFields();
    form.setFieldsValue({
      kingdeeUrl: 'https://dichanerp.huaxianggroup.cn/k3cloud/',
      status: 1,
      isDefault: false,
      defaultFormId: 'GL_VOUCHER',
    });
    setModalVisible(true);
  };

  const handleEdit = (account: KingdeeAccountConfig) => {
    setEditingId(account.id);
    form.setFieldsValue({
      accountName: account.accountName,
      kingdeeUrl: account.kingdeeUrl,
      dbId: account.dbId,
      username: account.username,
      password: '',
      orgCompanyCode: account.orgCompanyCode,
      useOrgCode: account.useOrgCode,
      defaultFormId: account.defaultFormId,
      defaultAccountingPeriod: account.defaultAccountingPeriod,
      isDefault: account.isDefault === 1,
      status: account.status,
      description: account.description,
    });
    setModalVisible(true);
  };

  const handleSave = async (values: AccountFormValues) => {
    const payload = {
      ...values,
      isDefault: values.isDefault ? 1 : 0,
    };
    if (!editingId && (!values.password || values.password === '******')) {
      message.error('新建账号时密码不能为空');
      return;
    }
    if (editingId && (!values.password || values.password === '******')) {
      delete (payload as { password?: string }).password;
    }
    try {
      if (editingId) {
        await updateKingdeeAccount(editingId, payload);
        message.success('账号已更新');
      } else {
        await createKingdeeAccount(payload);
        message.success('账号已添加');
      }
      setModalVisible(false);
      fetchAccounts();
    } catch {
      message.error('保存失败');
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await deleteKingdeeAccount(id);
      message.success('账号已删除');
      fetchAccounts();
    } catch {
      message.error('删除失败');
    }
  };

  const handleToggleStatus = async (id: number) => {
    try {
      await toggleKingdeeAccountStatus(id);
      message.success('状态已切换');
      fetchAccounts();
    } catch {
      message.error('切换失败');
    }
  };

  const handleSetDefault = async (id: number) => {
    try {
      await setDefaultKingdeeAccount(id);
      message.success('已设为默认账号');
      fetchAccounts();
    } catch {
      message.error('设置失败');
    }
  };

  const handleTestLogin = async (id: number) => {
    setTestingId(id);
    try {
      const res = await testKingdeeAccountLogin(id);
      message.success(res.data.message || '登录成功');
    } catch {
      message.error('登录测试失败');
    } finally {
      setTestingId(null);
    }
  };

  const columns: ColumnsType<KingdeeAccountConfig> = [
    { title: 'ID', dataIndex: 'id', width: 70 },
    { title: '账号名称', dataIndex: 'accountName', width: 140 },
    {
      title: '默认',
      dataIndex: 'isDefault',
      width: 80,
      render: (val: number) =>
        val === 1 ? <Tag color="gold">默认</Tag> : null,
    },
    {
      title: '状态',
      dataIndex: 'status',
      width: 80,
      render: (val: number) => (
        <Tag color={val === 1 ? 'green' : 'red'}>{val === 1 ? '启用' : '禁用'}</Tag>
      ),
    },
    { title: '金蝶地址', dataIndex: 'kingdeeUrl', ellipsis: true, width: 220 },
    { title: '账套ID', dataIndex: 'dbId', width: 140, ellipsis: true },
    { title: '用户名', dataIndex: 'username', width: 120 },
    { title: '公司编码', dataIndex: 'orgCompanyCode', width: 100 },
    { title: '使用组织', dataIndex: 'useOrgCode', width: 100 },
    { title: '默认表单', dataIndex: 'defaultFormId', width: 120 },
    { title: '默认期间', dataIndex: 'defaultAccountingPeriod', width: 100 },
    { title: '描述', dataIndex: 'description', ellipsis: true },
    {
      title: '更新时间',
      dataIndex: 'updatedAt',
      width: 170,
    },
    {
      title: '操作',
      width: 320,
      fixed: 'right',
      render: (_, record) => (
        <Space wrap>
          <Button type="link" icon={<EditOutlined />} onClick={() => handleEdit(record)}>
            编辑
          </Button>
          <Button
            type="link"
            icon={<ApiOutlined />}
            loading={testingId === record.id}
            onClick={() => handleTestLogin(record.id)}
          >
            测试登录
          </Button>
          {record.isDefault !== 1 && (
            <Button type="link" icon={<StarOutlined />} onClick={() => handleSetDefault(record.id)}>
              设为默认
            </Button>
          )}
          <Button
            type="link"
            icon={record.status === 1 ? <StopOutlined /> : <CheckCircleOutlined />}
            onClick={() => handleToggleStatus(record.id)}
          >
            {record.status === 1 ? '禁用' : '启用'}
          </Button>
          <Popconfirm
            title="确定删除此账号？"
            onConfirm={() => handleDelete(record.id)}
            okText="确定"
            cancelText="取消"
          >
            <Button type="link" danger icon={<DeleteOutlined />}>
              删除
            </Button>
          </Popconfirm>
        </Space>
      ),
    },
  ];

  return (
    <div className="page-container">
      <Card
        title="金蝶账号管理"
        extra={
          <Button type="primary" icon={<PlusOutlined />} onClick={handleAdd}>
            添加账号
          </Button>
        }
      >
        <Table
          rowKey="id"
          columns={columns}
          dataSource={accounts}
          loading={loading}
          scroll={{ x: 1800 }}
          pagination={false}
        />
      </Card>

      <Modal
        title={editingId ? '编辑金蝶账号' : '添加金蝶账号'}
        open={modalVisible}
        onCancel={() => setModalVisible(false)}
        footer={null}
        width={640}
        destroyOnClose
      >
        <Form form={form} layout="vertical" onFinish={handleSave}>
          <Form.Item
            label="账号名称"
            name="accountName"
            rules={[{ required: true, message: '请输入账号名称' }]}
          >
            <Input placeholder="如：华西地产默认账套" />
          </Form.Item>
          <Form.Item
            label="金蝶地址"
            name="kingdeeUrl"
            rules={[{ required: true, message: '请输入金蝶地址' }]}
          >
            <Input placeholder="https://dichanerp.huaxianggroup.cn/k3cloud/" />
          </Form.Item>
          <Form.Item
            label="账套ID (dbId)"
            name="dbId"
            rules={[{ required: true, message: '请输入账套ID' }]}
          >
            <Input placeholder="请输入账套ID" />
          </Form.Item>
          <Form.Item
            label="用户名"
            name="username"
            rules={[{ required: true, message: '请输入用户名' }]}
          >
            <Input placeholder="金蝶登录用户名" />
          </Form.Item>
          <Form.Item
            label="密码"
            name="password"
            rules={editingId ? [] : [{ required: true, message: '请输入密码' }]}
            extra={editingId ? '留空则保持原密码不变' : undefined}
          >
            <Input.Password placeholder={editingId ? '留空则不修改' : '金蝶登录密码'} />
          </Form.Item>
          <Form.Item label="公司/账簿编码" name="orgCompanyCode">
            <Input placeholder="如 106，用于凭证查询" />
          </Form.Item>
          <Form.Item label="使用组织编码" name="useOrgCode">
            <Input placeholder="用于供应商查询等，可选" />
          </Form.Item>
          <Form.Item label="默认表单ID" name="defaultFormId">
            <Input placeholder="如 GL_VOUCHER" />
          </Form.Item>
          <Form.Item label="默认会计期间" name="defaultAccountingPeriod">
            <Input placeholder="如 202511" />
          </Form.Item>
          <Form.Item label="描述" name="description">
            <Input.TextArea placeholder="备注说明（可选）" rows={2} />
          </Form.Item>
          <Form.Item label="设为默认账号" name="isDefault" valuePropName="checked">
            <Switch />
          </Form.Item>
          <Form.Item label="状态" name="status">
            <Select
              options={[
                { value: 1, label: '启用' },
                { value: 0, label: '禁用' },
              ]}
            />
          </Form.Item>
          <Form.Item>
            <Space>
              <Button type="primary" htmlType="submit">
                {editingId ? '保存修改' : '添加'}
              </Button>
              <Button onClick={() => setModalVisible(false)}>取消</Button>
            </Space>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
}
