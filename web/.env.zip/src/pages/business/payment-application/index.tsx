import { useState } from 'react';
import { Card, Form, Input, Row, Col, Radio, Select, Upload, Button, Table, Tag } from 'antd';
import { PlusOutlined, UploadOutlined } from '@ant-design/icons';
import type { ColumnsType } from 'antd/es/table';
import dayjs from 'dayjs';

interface PaymentDetailItem {
  key: number;
  serialNo: number;
  vehicleVin: string;
  overweightDate: string;
  plateNo: string;
  vehicleType: string;
  vehicleModel: string;
  supplier: string;
  salesman: string;
}

const detailColumns: ColumnsType<PaymentDetailItem> = [
  { title: '序号', dataIndex: 'serialNo', width: 60 },
  {
    title: '选择数据',
    width: 120,
    render: () => (
      <Button type="dashed" size="small">选择数据</Button>
    ),
  },
  { title: '编号', dataIndex: 'vehicleVin', width: 180, ellipsis: true, render: () => '暂无内容' },
  { title: '过磅日期', dataIndex: 'overweightDate', width: 120, render: () => '暂无内容' },
  { title: '车牌号', dataIndex: 'plateNo', width: 100, render: () => '暂无内容' },
  { title: '车辆类型', dataIndex: 'vehicleType', width: 100, render: () => '暂无内容' },
  { title: '车辆型号', dataIndex: 'vehicleModel', width: 150, ellipsis: true, render: () => '暂无内容' },
  { title: '供应商', dataIndex: 'supplier', width: 150, ellipsis: true, render: () => '暂无内容' },
  { title: '业务员', dataIndex: 'salesman', width: 100, render: () => '暂无内容' },
];

export default function PaymentApplicationPage() {
  const [form] = Form.useForm();
  const [detailItems, setDetailItems] = useState<PaymentDetailItem[]>([
    {
      key: 1,
      serialNo: 1,
      vehicleVin: '',
      overweightDate: '',
      plateNo: '',
      vehicleType: '',
      vehicleModel: '',
      supplier: '',
      salesman: '',
    },
  ]);

  const addDetailItem = () => {
    const newItem: PaymentDetailItem = {
      key: Date.now(),
      serialNo: detailItems.length + 1,
      vehicleVin: '',
      overweightDate: '',
      plateNo: '',
      vehicleType: '',
      vehicleModel: '',
      supplier: '',
      salesman: '',
    };
    setDetailItems([...detailItems, newItem]);
  };

  const handleSubmit = () => {
    form.validateFields().then((values) => {
      console.log('表单数据:', values);
    });
  };

  return (
    <div className="page-container">
      <Card title="发起流程" style={{ marginBottom: 0, borderRadius: 0 }}>
        <Form form={form} layout="vertical">
          <Row gutter={16}>
            <Col span={8}>
              <Form.Item label={<span>日期</span>} name="date">
                <Input
                  type="date"
                  defaultValue={dayjs().format('YYYY-MM-DD')}
                  readOnly
                  style={{ cursor: 'pointer' }}
                />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label={<span>*申请人</span>} name="applicant">
                <Input
                  placeholder="请选择申请人"
                  readOnly
                  style={{ cursor: 'pointer' }}
                  suffix={
                    <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                      <Tag color="blue">刘欢</Tag>
                      <span style={{ cursor: 'pointer', color: '#1890ff' }}>×</span>
                    </div>
                  }
                />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label={<span>*部门单选</span>} name="department">
                <Input
                  placeholder="请选择部门"
                  readOnly
                  style={{ cursor: 'pointer' }}
                  suffix={
                    <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                      <Tag color="green">AI部</Tag>
                      <span style={{ cursor: 'pointer', color: '#1890ff' }}>×</span>
                    </div>
                  }
                />
              </Form.Item>
            </Col>
          </Row>

          <div style={{ marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
              <Tag color="orange">付款明细</Tag>
            </div>
            <Table
              rowKey="key"
              columns={detailColumns}
              dataSource={detailItems}
              pagination={false}
              scroll={{ x: 1200 }}
              footer={() => (
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <Button type="dashed" icon={<PlusOutlined />} onClick={addDetailItem}>
                    + 添加
                  </Button>
                  <Button type="dashed" icon={<UploadOutlined />} size="small">快速填报</Button>
                </div>
              )}
            />
          </div>

          <Row gutter={16} style={{ marginBottom: 16 }}>
            <Col span={6}>
              <Form.Item label="合计金额(小写)" name="totalAmount">
                <Input placeholder="暂无内容" />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="合计金额(大写)" name="totalAmountCapital">
                <Input placeholder="暂无内容" />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="车辆数量" name="vehicleCount">
                <Input placeholder="暂无内容" />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="总吨位" name="totalTonnage">
                <Input placeholder="暂无内容" />
              </Form.Item>
            </Col>
          </Row>

          <div style={{ marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
              <Tag color="blue">付款信息</Tag>
            </div>
            <div style={{ borderTop: '1px dashed #d9d9d9' }} />
          </div>

          <Row gutter={16} style={{ marginBottom: 16 }}>
            <Col span={8}>
              <Form.Item label={<span>*付款账户</span>} name="paymentAccount">
                <Radio.Group defaultValue="big">
                  <Radio value="big"><Tag color="blue">大账户</Tag></Radio>
                  <Radio value="small"><Tag color="orange">小账户</Tag></Radio>
                </Radio.Group>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label={<span>*付款方式</span>} name="paymentMethod">
                <Radio.Group defaultValue="cash">
                  <Radio value="cash"><Tag color="red">现金</Tag></Radio>
                  <Radio value="bank"><Tag color="yellow">电汇</Tag></Radio>
                  <Radio value="transfer"><Tag color="green">承兑</Tag></Radio>
                </Radio.Group>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="收款单位1" name="payeeName">
                <Select
                  placeholder="请选择收款单位"
                  style={{ width: '100%' }}
                  allowClear
                />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16} style={{ marginBottom: 16 }}>
            <Col span={8}>
              <Form.Item label="开户行1" name="bankName">
                <Select
                  placeholder="请选择开户行"
                  style={{ width: '100%' }}
                  allowClear
                />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="银行账号1" name="bankAccount">
                <Input placeholder="请输入银行账号" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="收款账号1" name="payeeAccount">
                <Input placeholder="请输入收款账号" />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16} style={{ marginBottom: 16 }}>
            <Col span={16}>
              <Form.Item label="图片" name="image">
                <Upload
                  action="/upload"
                  listType="picture-card"
                  accept="image/*"
                  showUploadList={{ showPreviewIcon: true, showRemoveIcon: true }}
                  maxCount={1}
                >
                  <div>
                    <UploadOutlined />
                    <div style={{ marginTop: 8 }}>选择 拖拽或单击后粘贴图片，单张20MB以内</div>
                  </div>
                </Upload>
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16} style={{ marginBottom: 16 }}>
            <Col span={24}>
              <Form.Item label="附件" name="attachment">
                <Upload.Dragger
                  action="/upload"
                  accept=".pdf,.doc,.docx,.xls,.xlsx"
                  showUploadList={{ showPreviewIcon: false, showRemoveIcon: true }}
                >
                  <p className="ant-upload-drag-icon">
                    <UploadOutlined />
                  </p>
                  <p className="ant-upload-text">选择 拖拽或单击后粘贴文件，单个500MB以内</p>
                </Upload.Dragger>
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item label="付款事由" name="paymentReason">
                <Input.TextArea
                  rows={6}
                  placeholder="请输入付款事由"
                />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16} style={{ marginTop: 24 }}>
            <Col span={24} style={{ display: 'flex', justifyContent: 'flex-start', gap: 16 }}>
              <Button type="primary" size="large" onClick={handleSubmit}>提交申请</Button>
              <Button size="large">保存草稿</Button>
            </Col>
          </Row>
        </Form>
      </Card>
    </div>
  );
}