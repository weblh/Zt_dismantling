import { useState, useEffect, useCallback } from 'react';
import { Card, Table, Select, DatePicker } from 'antd';
import { ReloadOutlined, ColumnWidthOutlined, FullscreenOutlined, UploadOutlined } from '@ant-design/icons';
import type { ColumnsType } from 'antd/es/table';
import dayjs from 'dayjs';

interface VehicleReceiptItem {
  id: number;
  vehicleVin: string;
  vehiclePlate: string;
  vehicleModel: string;
  receiptDate: string;
  receiptAmount: number;
  supplierName: string;
  businessStatus: string;
  createdAt: string;
}

const columns: ColumnsType<VehicleReceiptItem> = [];

const mockData: VehicleReceiptItem[] = [];

export default function VehicleReceiptStatisticsPage() {
  const [items, setItems] = useState<VehicleReceiptItem[]>([]);
  const [total, setTotal] = useState(0);
  const [pageNo, setPageNo] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [loading, setLoading] = useState(false);
  const [overweightDate, setOverweightDate] = useState('today');
  const [customDate, setCustomDate] = useState<dayjs.Dayjs | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 500));
      setItems(mockData);
      setTotal(mockData.length);
    } catch {
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return (
    <div className="page-container">
      <Card style={{ margin: 0, borderRadius: 0, overflow: 'hidden' }}>
        <div style={{ padding: '8px 24px', borderBottom: '1px solid #e8e8e8', display: 'flex', alignItems: 'center' }}>
          <span style={{ fontSize: 16, fontWeight: 500, marginRight: 16 }}>业务收车统计表</span>
          <UploadOutlined style={{ fontSize: 16, cursor: 'pointer', color: '#666', marginRight: 16 }} />
          <FullscreenOutlined style={{ fontSize: 16, cursor: 'pointer', color: '#666' }} />
        </div>

        <div style={{ padding: '12px 24px', background: '#f5f5f5', borderBottom: '1px solid #e8e8e8' }}>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
            <span style={{ fontSize: 14, color: '#666', marginRight: 12 }}>过磅日期</span>
            <span style={{ display: 'flex', alignItems: 'center', padding: '2px 8px', background: '#e6f7ff', color: '#1890ff', fontSize: 12, borderRadius: 4 }}>
              动态筛选
              <span style={{ marginLeft: 4, fontSize: 10 }}>▼</span>
            </span>
          </div>
          <div style={{ display: 'flex', gap: 16 }}>
            <Select
              value={overweightDate}
              onChange={setOverweightDate}
              style={{ width: 160 }}
              options={[
                { value: 'today', label: '今天' },
                { value: 'yesterday', label: '昨天' },
                { value: 'week', label: '本周' },
                { value: 'month', label: '本月' },
                { value: 'custom', label: '自定义' },
              ]}
            />
            {overweightDate === 'custom' && (
              <DatePicker
                value={customDate}
                onChange={(date) => setCustomDate(date)}
                placeholder="选择日期"
                style={{ width: 160 }}
              />
            )}
          </div>
        </div>

        <div style={{ padding: '0 24px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid #e8e8e8' }}>
            <span style={{ fontSize: 14, fontWeight: 500 }}>业务收车统计表</span>
            <div style={{ display: 'flex', gap: 16 }}>
              <UploadOutlined style={{ fontSize: 16, cursor: 'pointer', color: '#666' }} />
              <ReloadOutlined style={{ fontSize: 16, cursor: 'pointer', color: '#666' }} />
              <ColumnWidthOutlined style={{ fontSize: 16, cursor: 'pointer', color: '#666' }} />
              <FullscreenOutlined style={{ fontSize: 16, cursor: 'pointer', color: '#666' }} />
            </div>
          </div>

          <Table
            rowKey="id"
            columns={columns}
            dataSource={items}
            loading={loading}
            pagination={{
              current: pageNo,
              pageSize,
              total,
              showSizeChanger: false,
              onChange: (page, size) => {
                setPageNo(page);
                setPageSize(size);
              },
            }}
          />
        </div>
      </Card>
    </div>
  );
}