import { useState } from 'react';
import { Form, Input, Select, DatePicker, Button, Radio, Upload, message, Checkbox } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import zhCN from 'antd/es/date-picker/locale/zh_CN';

export default function MobileFormPage() {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);

  const handleSubmit = () => {
    form.validateFields().then((values) => {
      setLoading(true);
      setTimeout(() => {
        console.log('表单数据:', values);
        message.success('提交成功！');
        form.resetFields();
        setLoading(false);
      }, 1000);
    }).catch((errorInfo) => {
      console.log('表单验证失败:', errorInfo);
    });
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #E0F4FF 0%, #B8E4F7 50%, #87CEEB 100%)',
      padding: '20px',
      position: 'relative',
      overflow: 'visible',
    }}>
      {/* 背景装饰元素 */}
      <div style={{
        position: 'absolute',
        top: '-100px',
        right: '-100px',
        width: '300px',
        height: '300px',
        background: 'radial-gradient(circle, rgba(9, 132, 227, 0.1) 0%, transparent 70%)',
        borderRadius: '50%',
      }}></div>
      <div style={{
        position: 'absolute',
        bottom: '-80px',
        left: '-80px',
        width: '250px',
        height: '250px',
        background: 'radial-gradient(circle, rgba(91, 184, 232, 0.15) 0%, transparent 70%)',
        borderRadius: '50%',
      }}></div>
      <div style={{
        position: 'absolute',
        top: '50%',
        right: '20%',
        width: '150px',
        height: '150px',
        background: 'radial-gradient(circle, rgba(135, 206, 235, 0.1) 0%, transparent 70%)',
        borderRadius: '50%',
        transform: 'translateY(-50%)',
      }}></div>
      <div style={{
        position: 'absolute',
        top: '20%',
        left: '10%',
        width: '80px',
        height: '80px',
        background: 'radial-gradient(circle, rgba(9, 132, 227, 0.08) 0%, transparent 70%)',
        borderRadius: '50%',
      }}></div>
      <div style={{
        position: 'relative',
        zIndex: 1,
        background: '#FFFFFF',
        borderRadius: '12px',
        padding: '24px',
        border: '1px solid rgba(9, 132, 227, 0.15)',
        boxShadow: '0 4px 24px rgba(9, 132, 227, 0.12)',
      }}>
        <div style={{
          textAlign: 'center',
          marginBottom: '24px',
          paddingBottom: '16px',
          borderBottom: '1px solid #E0F4FF',
        }}>
          <h1 style={{
            fontSize: '20px',
            fontWeight: 'bold',
            color: '#0984e3',
            margin: 0,
          }}>维修工单表单</h1>
        </div>

        <Form
          form={form}
          layout="vertical"
          style={{
            color: '#999999',
          }}
        >
          <div style={{
            marginBottom: '24px',
            paddingBottom: '16px',
            borderBottom: '1px dashed #E0F4FF',
          }}>
            <h2 style={{
              fontSize: '16px',
              fontWeight: 'bold',
              color: '#0984e3',
              marginBottom: '16px',
            }}>一、基础信息与设备档案</h2>

            <Form.Item
              label="工单编号"
              name="workOrderNo"
              rules={[{ required: true, message: '请输入工单编号' }]}
              labelCol={{ style: { marginBottom: '8px' } }}
            >
              <Input
                placeholder="请输入工单编号"
                style={{
                  background: '#FFFFFF',
                  border: '1px solid #B8E4F7',
                  color: '#333333',
                  borderRadius: '8px',
                }}
              />
            </Form.Item>

            <Form.Item
              label="设备/资产信息"
              name="equipmentInfo"
              rules={[{ required: true, message: '请输入设备/资产信息' }]}
              labelCol={{ style: { marginBottom: '8px' } }}
            >
              <Input.TextArea
                placeholder="请输入设备名称、型号、资产编号等信息"
                rows={3}
                style={{
                  background: '#FFFFFF',
                  border: '1px solid #B8E4F7',
                  color: '#333333',
                  borderRadius: '8px',
                }}
              />
            </Form.Item>

            <Form.Item
              label="报修信息"
              name="repairInfo"
              rules={[{ required: true, message: '请输入报修信息' }]}
              labelCol={{ style: { marginBottom: '8px' } }}
            >
              <Input.TextArea
                placeholder="请描述故障现象、报修时间、报修人等信息"
                rows={3}
                style={{
                  background: '#FFFFFF',
                  border: '1px solid #B8E4F7',
                  color: '#333333',
                  borderRadius: '8px',
                }}
              />
            </Form.Item>
          </div>

          <div style={{
            marginBottom: '24px',
            paddingBottom: '16px',
            borderBottom: '1px dashed #E0F4FF',
          }}>
            <h2 style={{
              fontSize: '16px',
              fontWeight: 'bold',
              color: '#0984e3',
              marginBottom: '16px',
            }}>二、维修执行与过程记录</h2>

            <Form.Item
              label="承接部门"
              name="department"
              rules={[{ required: true, message: '请选择承接部门' }]}
              labelCol={{ style: { marginBottom: '8px' } }}
            >
              <Select
                placeholder="请选择承接部门"
                options={[
                  { value: 'maintenance', label: '维修部' },
                  { value: 'electrical', label: '电气部' },
                  { value: 'mechanical', label: '机械部' },
                  { value: 'it', label: 'IT部' },
                  { value: 'other', label: '其他' },
                ]}
                style={{
                  background: '#FFFFFF',
                  border: '1px solid #B8E4F7',
                  color: '#333333',
                  borderRadius: '8px',
                }}
                dropdownStyle={{
                  background: '#FFFFFF',
                  border: '1px solid #B8E4F7',
                  color: '#333333',
                }}
              />
            </Form.Item>

            <Form.Item
              label="维修负责人"
              name="repairLeader"
              rules={[{ required: true, message: '请输入维修负责人' }]}
              labelCol={{ style: { marginBottom: '8px' } }}
            >
              <Input
                placeholder="请输入维修负责人姓名"
                style={{
                  background: '#FFFFFF',
                  border: '1px solid #B8E4F7',
                  color: '#333333',
                  borderRadius: '8px',
                }}
              />
            </Form.Item>

            <Form.Item
              label="计划完成时间"
              name="plannedCompleteTime"
              rules={[{ required: true, message: '请选择计划完成时间' }]}
              labelCol={{ style: { marginBottom: '8px' } }}
            >
              <DatePicker
                locale={zhCN}
                showTime={{ format: 'HH:mm' }}
                format="YYYY-MM-DD HH:mm"
                style={{
                  width: '100%',
                  background: '#FFFFFF',
                  border: '1px solid #B8E4F7',
                  color: '#333333',
                  borderRadius: '8px',
                }}
                placeholder="请选择计划完成时间"
              />
            </Form.Item>

            <Form.Item
              label="故障类型"
              name="faultType"
              rules={[{ required: true, message: '请选择故障类型' }]}
              labelCol={{ style: { marginBottom: '8px' } }}
            >
              <Select
                placeholder="请选择故障类型"
                options={[
                  { value: 'hardware', label: '硬件故障' },
                  { value: 'software', label: '软件故障' },
                  { value: 'network', label: '网络故障' },
                  { value: 'power', label: '电源故障' },
                  { value: 'mechanical', label: '机械故障' },
                  { value: 'other', label: '其他故障' },
                ]}
                style={{
                  background: '#FFFFFF',
                  border: '1px solid #B8E4F7',
                  color: '#333333',
                  borderRadius: '8px',
                }}
                dropdownStyle={{
                  background: '#FFFFFF',
                  border: '1px solid #B8E4F7',
                  color: '#333333',
                }}
              />
            </Form.Item>

            <Form.Item
              label="处理过程"
              name="processRecord"
              rules={[{ required: true, message: '请输入处理过程' }]}
              labelCol={{ style: { marginBottom: '8px' } }}
            >
              <Input.TextArea
                placeholder="请详细描述维修处理过程、更换部件、调试步骤等"
                rows={4}
                style={{
                  background: '#FFFFFF',
                  border: '1px solid #B8E4F7',
                  color: '#333333',
                  borderRadius: '8px',
                }}
              />
            </Form.Item>

            <Form.Item
              label="维修结果"
              name="repairResult"
              rules={[{ required: true, message: '请选择维修结果' }]}
              labelCol={{ style: { marginBottom: '8px' } }}
            >
              <Radio.Group
                options={[
                  { value: 'repaired', label: '已修复' },
                  { value: 'partial', label: '部分修复' },
                  { value: 'pending', label: '待配件' },
                  { value: 'unrepairable', label: '无法修复' },
                ]}
                buttonStyle="solid"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '8px',
                }}
              />
            </Form.Item>
          </div>

          <div style={{
            marginBottom: '24px',
            paddingBottom: '16px',
            borderBottom: '1px dashed #E0F4FF',
          }}>
            <h2 style={{
              fontSize: '16px',
              fontWeight: 'bold',
              color: '#0984e3',
              marginBottom: '16px',
            }}>三、当前状态和时间戳</h2>

            <Form.Item
              label="当前状态"
              name="currentStatus"
              rules={[{ required: true, message: '请选择当前状态' }]}
              labelCol={{ style: { marginBottom: '8px' } }}
            >
              <Radio.Group
                options={[
                  { value: 'pending', label: '待接单' },
                  { value: 'accepted', label: '已接单' },
                  { value: 'processing', label: '处理中' },
                  { value: 'completed', label: '已完成' },
                  { value: 'verified', label: '已验收' },
                ]}
                buttonStyle="solid"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '8px',
                }}
              />
            </Form.Item>

            <Form.Item
              label="创建时间"
              name="createTime"
              rules={[{ required: true, message: '请选择创建时间' }]}
              labelCol={{ style: { marginBottom: '8px' } }}
            >
              <DatePicker
                locale={zhCN}
                showTime={{ format: 'HH:mm' }}
                format="YYYY-MM-DD HH:mm"
                style={{
                  width: '100%',
                  background: '#FFFFFF',
                  border: '1px solid #B8E4F7',
                  color: '#333333',
                  borderRadius: '8px',
                }}
                placeholder="请选择创建时间"
              />
            </Form.Item>

            <Form.Item
              label="实际完成时间"
              name="actualCompleteTime"
              labelCol={{ style: { marginBottom: '8px' } }}
            >
              <DatePicker
                locale={zhCN}
                showTime={{ format: 'HH:mm' }}
                format="YYYY-MM-DD HH:mm"
                style={{
                  width: '100%',
                  background: '#FFFFFF',
                  border: '1px solid #B8E4F7',
                  color: '#333333',
                  borderRadius: '8px',
                }}
                placeholder="请选择实际完成时间"
              />
            </Form.Item>
          </div>

          <div style={{
            marginBottom: '24px',
          }}>
            <h2 style={{
              fontSize: '16px',
              fontWeight: 'bold',
              color: '#0984e3',
              marginBottom: '16px',
            }}>四、验收与附加信息</h2>

            <Form.Item
              label="验收确认"
              name="acceptanceConfirm"
              valuePropName="checked"
              rules={[{ required: true, message: '请确认验收' }]}
              labelCol={{ style: { marginBottom: '8px' } }}
            >
              <Checkbox
                style={{
                  color: '#00d9ff',
                }}
              >
                本人已验收，确认维修结果符合要求
              </Checkbox>
            </Form.Item>

            <Form.Item
              label="验收人"
              name="acceptor"
              rules={[{ required: true, message: '请输入验收人' }]}
              labelCol={{ style: { marginBottom: '8px' } }}
            >
              <Input
                placeholder="请输入验收人姓名"
                style={{
                  background: '#FFFFFF',
                  border: '1px solid #B8E4F7',
                  color: '#333333',
                  borderRadius: '8px',
                }}
              />
            </Form.Item>

            <Form.Item
              label="验收时间"
              name="acceptanceTime"
              labelCol={{ style: { marginBottom: '8px' } }}
            >
              <DatePicker
                locale={zhCN}
                showTime={{ format: 'HH:mm' }}
                format="YYYY-MM-DD HH:mm"
                style={{
                  width: '100%',
                  background: '#FFFFFF',
                  border: '1px solid #B8E4F7',
                  color: '#333333',
                  borderRadius: '8px',
                }}
                placeholder="请选择验收时间"
              />
            </Form.Item>

            <Form.Item
              label="备注"
              name="remarks"
              labelCol={{ style: { marginBottom: '8px' } }}
            >
              <Input.TextArea
                placeholder="请输入其他备注信息"
                rows={3}
                style={{
                  background: '#FFFFFF',
                  border: '1px solid #B8E4F7',
                  color: '#333333',
                  borderRadius: '8px',
                }}
              />
            </Form.Item>

            <Form.Item label="附件">
              <Upload.Dragger
                beforeUpload={() => false}
                style={{
                  background: '#F0F9FF',
                  border: '1px dashed #B8E4F7',
                  borderRadius: '8px',
                }}
              >
                <p style={{ color: '#0984e3' }}>
                  <UploadOutlined style={{ fontSize: '24px', marginBottom: '8px' }} />
                </p>
                <p style={{ color: '#666666', fontSize: '14px' }}>点击或拖拽文件到此处上传</p>
              </Upload.Dragger>
            </Form.Item>
          </div>

          <Form.Item style={{ marginTop: '24px', marginBottom: 0 }}>
            <Button
              type="primary"
              size="large"
              block
              onClick={handleSubmit}
              loading={loading}
              style={{
                background: 'linear-gradient(90deg, #0984e3 0%, #00d9ff 100%)',
                border: 'none',
                borderRadius: '8px',
                height: '48px',
                fontSize: '16px',
                fontWeight: 'bold',
                boxShadow: '0 0 20px rgba(0, 217, 255, 0.3)',
              }}
            >
              提交工单
            </Button>
          </Form.Item>
        </Form>
        <style>{`
          .ant-form-item-label > label {
            color: #333333 !important;
            font-weight: 500;
          }
          .ant-select-item-option-content {
            color: #333333 !important;
          }
          .ant-select-dropdown-menu-item {
            color: #333333 !important;
          }
          .ant-radio-wrapper {
            color: #333333 !important;
          }
          .ant-checkbox-wrapper {
            color: #333333 !important;
          }
          .ant-upload-text {
            color: #666666 !important;
          }
          /* 所有占位符统一灰色 */
          *::placeholder,
          *::-webkit-input-placeholder,
          *::-moz-placeholder,
          *:-ms-input-placeholder {
            color: #999999 !important;
            opacity: 1 !important;
          }
          .ant-select-selection-placeholder,
          .ant-select-single.ant-select-show-arrow .ant-select-selection-placeholder,
          .ant-select-selector .ant-select-selection-placeholder,
          .ant-select-placeholder,
          .ant-input-placeholder,
          .ant-picker-placeholder {
            color: #999999 !important;
            opacity: 1 !important;
          }
          .ant-select-selector {
            color: #333333 !important;
          }
          .ant-picker-input > input {
            color: #333333 !important;
          }
          .ant-input {
            color: #333333 !important;
          }
          .ant-input-textarea {
            color: #333333 !important;
          }
          .ant-radio-button-wrapper-checked {
            background-color: #0984e3 !important;
            color: #fff !important;
            border-color: #0984e3 !important;
          }
          .ant-checkbox-inner {
            border-color: #B8E4F7 !important;
          }
          .ant-checkbox-checked .ant-checkbox-inner {
            background-color: #0984e3 !important;
            border-color: #0984e3 !important;
          }
        `}</style>
        </div>
      </div>
  );
}