import { useState } from 'react';
import { Layout, Menu, Dropdown, Avatar, Input, theme } from 'antd';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import {
  CarOutlined,
  ClockCircleOutlined,
  SendOutlined,
  CheckCircleOutlined,
  MailOutlined,
  SearchOutlined,
  FolderOpenOutlined,
  BarChartOutlined,
  DatabaseOutlined,
  DashboardOutlined,
  TruckOutlined,
  InboxOutlined,
  FileTextOutlined,
  UserOutlined,
  LogoutOutlined,
  EnvironmentOutlined,
  PictureOutlined,
  PayCircleOutlined,
  TagOutlined,
  ShoppingFilled,
  HomeOutlined,
  WarningOutlined,
  SettingOutlined,
  AppstoreOutlined,
} from '@ant-design/icons';
import type { MenuProps } from 'antd';

const { Header, Sider, Content } = Layout;

const menuItems: MenuProps['items'] = [
  {
    key: 'todo',
    icon: <ClockCircleOutlined />,
    label: '我的待办',
  },
  {
    key: 'initiated',
    icon: <SendOutlined />,
    label: '我发起的',
  },
  {
    key: 'processed',
    icon: <CheckCircleOutlined />,
    label: '我处理的',
  },
  {
    key: 'copied',
    icon: <MailOutlined />,
    label: '抄送我的',
  },
  {
    type: 'divider',
  },
  {
    key: 'search',
    label: (
      <Input
        placeholder="输入名称来搜索"
        prefix={<SearchOutlined />}
        style={{ width: '100%' }}
        allowClear
      />
    ),
  },
  {
    type: 'divider',
  },
  {
    key: 'business',
    icon: <FolderOpenOutlined />,
    label: '业务',
    children: [
      { key: '/business/receipt', icon: <ShoppingFilled />, label: '1.业务收货' },
      { key: '/business/vehicle-photo', icon: <PictureOutlined />, label: '异地车固照片' },
      { key: '/business/settlement', icon: <FileTextOutlined />, label: '业务结账' },
      { key: '/business/payment-application', icon: <PayCircleOutlined />, label: '业务结账付款申请' },
      { key: '/business/price-change', icon: <TagOutlined />, label: '修改价格' },
      { key: '/business/vehicle-receipt-statistics', icon: <BarChartOutlined />, label: '业务收车统计表' },
    ],
  },
  {
    key: '/inspection-location',
    icon: <EnvironmentOutlined />,
    label: '巡检地点',
  },
  {
    key: 'production',
    icon: <DatabaseOutlined />,
    label: '生产',
    children: [
      { key: '/kingdee/voucher', icon: <DatabaseOutlined />, label: '1.过磅同步数据' },
      { key: '/production/weighing-inspection', icon: <UserOutlined />, label: '2.过磅查验' },
      { key: '/production/inspection-photo', icon: <HomeOutlined />, label: '3.查验照片' },
      { key: '/production/scrapped-vehicle', icon: <WarningOutlined />, label: '4.报废车入库' },
      { key: '/production/pick-top-photo', icon: <PictureOutlined />, label: '5.挑顶照片' },
      { key: '/production/disassembly', icon: <SettingOutlined />, label: '6.拆解' },
      { key: '/production/comprehensive-disassembly', icon: <AppstoreOutlined />, label: '7.综合拆解' },
    ],
  },
  {
    key: 'dashboard',
    icon: <DashboardOutlined />,
    label: '展示看板',
    children: [
      { key: '/home', icon: <DashboardOutlined />, label: '业务看板' },
    ],
  },
  {
    key: 'agriculture',
    icon: <TruckOutlined />,
    label: '农机业务',
    children: [
      { key: '/kingdee/supplier', icon: <InboxOutlined />, label: '原材料-农机入库' },
      { key: '/kingdee/account', icon: <InboxOutlined />, label: '原材料-农机出库' },
      { key: '/dingtalk/form-config', icon: <InboxOutlined />, label: '原材料-农机剩余库存' },
      { key: '/dingtalk/oa-form-data', icon: <InboxOutlined />, label: '农机成品入库' },
      { key: '/business/expense-reimbursement', icon: <InboxOutlined />, label: '农机成品出库' },
      { key: '/business/fund-usage-application', icon: <InboxOutlined />, label: '成品剩余' },
    ],
  },
  {
    type: 'divider',
  },
  {
    key: 'procedures',
    icon: <FileTextOutlined />,
    label: '手续',
  },
];

export default function AppLayout() {
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  theme.useToken();

  const userStr = localStorage.getItem('user');
  const user = userStr ? JSON.parse(userStr) : { nickname: '用户', username: '' };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  const userMenu: MenuProps['items'] = [
    {
      key: 'logout',
      icon: <LogoutOutlined />,
      label: '退出登录',
      onClick: handleLogout,
    },
  ];

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Sider
        collapsible
        collapsed={collapsed}
        onCollapse={setCollapsed}
        theme="light"
        width={220}
        style={{
          borderRight: '1px solid #E0F4FF',
          background: '#F0F9FF',
        }}
      >
        <div
          style={{
            height: 50,
            display: 'flex',
            alignItems: 'center',
            padding: '0 16px',
            borderBottom: '1px solid #f0f0f0',
            background: '#fff',
          }}
        >
          <CarOutlined style={{ fontSize: 20, color: '#ff4d4f', marginRight: 8 }} />
          <span style={{ fontSize: 14, fontWeight: 500, color: '#333' }}>汽车拆解-收车</span>
        </div>
        <Menu
          theme="light"
          mode="inline"
          selectedKeys={[location.pathname]}
          items={menuItems}
          onClick={({ key }) => {
            if (key.startsWith('/')) {
              navigate(key);
            }
          }}
          style={{
            background: '#F0F9FF',
            borderRight: 'none',
          }}
        />
      </Sider>
      <Layout>
        <Header
          style={{
            padding: '0 24px',
            background: '#fff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'flex-end',
            borderBottom: '1px solid #f0f0f0',
          }}
        >
          <Dropdown menu={{ items: userMenu }} placement="bottomRight">
            <div style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8 }}>
              <Avatar icon={<UserOutlined />} style={{ backgroundColor: '#fff', border: '1px solid #f0f0f0' }} />
              <span>{user.nickname || user.username}</span>
            </div>
          </Dropdown>
        </Header>
        <Content style={{ margin: 0, minHeight: 280, background: '#fafafa', overflow: 'visible' }}>
          <Outlet />
        </Content>
      </Layout>
    </Layout>
  );
}