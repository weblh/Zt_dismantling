import { Card, Button, Space } from 'antd';
import { PlusOutlined, SearchOutlined, FilterOutlined } from '@ant-design/icons';

export default function ScrappedVehicle() {
  return (
    <div style={{ padding: 16 }}>
      <Card>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
          <h2 style={{ margin: 0 }}>报废车入库</h2>
          <Space>
            <Button type="primary" icon={<PlusOutlined />}>添加</Button>
            <Button icon={<SearchOutlined />}>搜索</Button>
            <Button icon={<FilterOutlined />}>筛选</Button>
          </Space>
        </div>
        <div style={{ textAlign: 'center', padding: '40px 0', color: '#999' }}>
          暂无数据
        </div>
      </Card>
    </div>
  );
}
